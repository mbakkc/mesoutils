﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MesOutils
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string login = GetLoginString(User.Identity.Name);
            string sUrltoto = ConfigurationManager.AppSettings["UrlPortal"];
            DataSet ds = GetIcapLinks(login);
            lblMenu.Text = "";
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblMenu.Text += "<div class=\"wrapper bodywrapper\" dir=\"auto\">\r\n";
                lblMenu.Text += "    <div class=\"page home\">\r\n";
                lblMenu.Text += "        <div class=\"w25p\">\r\n";
                lblMenu.Text += "            <div class=\"user-box\">\r\n";
                lblMenu.Text += "                <div id=\"myTools\" class=\"my-tools\">\r\n";
                lblMenu.Text += "                    <h2>Mes Outils France</h2>\r\n";
                lblMenu.Text += "                    <div id=\"my-tools-links\">\r\n";
                lblMenu.Text += "                        <ol>\r\n";
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    lblMenu.Text += "                            <li><a href=\""
                                 + (row["appl_link"].ToString().StartsWith("/") ? sUrltoto + row["appl_link"].ToString() : row["appl_link"].ToString())
                                 + "\" title=\""
                                 + row["appl_description"].ToString() 
                                 + "\" target=\""
                                 + row["target"].ToString() 
                                 + "\">"
                                 + row["appl_description"].ToString()
                                 + "</a></li>\r\n";
                }
                lblMenu.Text += "                        </ol>\r\n";
                lblMenu.Text += "	                </div><!-- # my-tools-links -->\r\n";
                lblMenu.Text += "                </div>\r\n";
                lblMenu.Text += "            </div>\r\n";
                lblMenu.Text += "        </div>\r\n";
                lblMenu.Text += "    </div>\r\n";
                lblMenu.Text += "</div>\r\n";
                ds.Dispose();
                ds = null;
            }
        }

        protected static string GetLoginString(string FullLoginString)
        {

            string Result = null;
            try
            {

                Result = FullLoginString.Substring(FullLoginString.LastIndexOf("\\") + 1, (FullLoginString.Length - FullLoginString.LastIndexOf("\\")) - 1);
            }
            catch (Exception UnknownException)
            {
                throw UnknownException;
            }
            return Result;
        }

        public DataSet GetIcapLinks(string userName) 
		{
            using (SqlConnection myConnection = new SqlConnection())
            {
                // Now Pass a Connection String To the Connection
                myConnection.ConnectionString = ConfigurationManager.AppSettings["ConnectionString1"];

                // Now the command statement you want to run
                SqlCommand myCommand = new SqlCommand("POR_GetICAPLinks", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Fill The Parameter
                SqlParameter pUserName = new SqlParameter("@av_username", SqlDbType.VarChar, 30);
                pUserName.Value = (userName == null ? "" : userName);
                myCommand.Parameters.Add(pUserName);

                var adapter = new SqlDataAdapter(myCommand);
                DataSet ds = new DataSet("POR_GetICAPLinks");
                adapter.Fill(ds, "POR_GetICAPLinks");
                // Now Return ds which is a DataSet
                return (ds);
            }

        }
    }
}